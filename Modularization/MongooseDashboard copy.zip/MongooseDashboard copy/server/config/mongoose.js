console.log("******Mongoose*******")
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/random_db', {useNewUrlParser: true});