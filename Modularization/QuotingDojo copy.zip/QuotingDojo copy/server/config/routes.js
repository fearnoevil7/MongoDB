const mongoose = require('mongoose'),
    Quote = mongoose.model('User')
module.exports = function(app){
    app.get('/', (req, res) => {
        res.render("index");
    });
    app.get('/quotes', (req, res) => {
        console.log("*******!!!!!!!*******")
        User.find()
            .then(users => {
                console.log(users),
                res.render("home", {users})
        })
            .catch(err => res.json(err));
    });
    
    app.post('/quotes', (req, res) => {
        const user = new User();
        user.name = req.body.name;
        user.quote = req.body.quote;
        // user.created_at = req.body.created_at;
        console.log("Success!!!!!!!")
        console.log("Yay!!!!!!!!")
        console.log(req.body)
        user.save()
            .then(newUserData => console.log('user created: ', newUserData))
            .catch(err => console.log(err))
        res.redirect('/quotes');
    });

}
